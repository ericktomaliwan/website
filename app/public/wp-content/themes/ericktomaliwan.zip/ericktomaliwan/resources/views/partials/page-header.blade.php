<div class="page-header">
  <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
    @if ( !is_page() )
      <h1 class="inline-block text-2xl sm:text-3xl font-extrabold">{!! $title !!}</h1>
    @endif
  </div>
</div>

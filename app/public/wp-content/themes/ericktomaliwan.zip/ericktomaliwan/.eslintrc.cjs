module.exports = {
  root: true,
  extends: ['@roots/eslint-config/sage'],
};